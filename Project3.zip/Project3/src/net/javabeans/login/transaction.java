package net.javabeans.login;
import javax.servlet. * ;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql. * ;
import java.sql.Date;
@WebServlet("/transaction")
public class transaction extends HttpServlet {
  private static long serialVersionUID = 1L;
  PrintWriter out = new PrintWriter(System.out);
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
  IOException{
    System.out.println("in transaction");
    String t_to,
    t_from,
    curr_date;
    HttpSession session = request.getSession(false);
    int account_no = (int) session.getAttribute("account_no");
    String acc_no = request.getParameter("acc_no");
    int amt = Integer.parseInt(request.getParameter("amt"));
    String button123 = request.getParameter("input123");
    System.out.println(account_no + " " + acc_no + " " + amt + " " + button123);
    long millis = System.currentTimeMillis();
    java.sql.Date date = new java.sql.Date(millis);
    curr_date = date.toString();
    if ("Debit".equals(button123)) {
      t_to = acc_no;
      t_from = Integer.toString(account_no);

      
    }
    else {
      t_to = Integer.toString(account_no);
      t_from = acc_no;
    }
    try {
      Class.forName("com.mysql.cj.jdbc.Driver");
      Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/login?useSSL=false", "root", "12345");
      String query = "Insert into transaction(account_no,t_type,t_to,t_from,amount,t_date) values(?,?,?,?,?,?);";
      PreparedStatement pstmt = conn.prepareStatement(query);
      pstmt.setInt(1, account_no);
      pstmt.setString(2, button123);
      pstmt.setString(3, t_to);
      pstmt.setString(4, t_from);
      pstmt.setInt(5, amt);
      pstmt.setString(6, curr_date);
      int x = pstmt.executeUpdate();
      if ("Debit".equals(button123)) {
        //t_to = acc_no;
        //t_from = Integer.toString(account_no);
        PreparedStatement preparedStatement = conn.prepareStatement("select amount from acc where account_no = ?");
        preparedStatement.setInt(1, account_no);
        System.out.println(preparedStatement);
        ResultSet rs = preparedStatement.executeQuery();
        rs.next();
        int new_amount = rs.getInt(1) - amt;
        PreparedStatement preparedStatement2 = conn.prepareStatement("Update acc set amount = ? where account_no = ?");
        preparedStatement2.setInt(1, new_amount);
        preparedStatement2.setInt(2, account_no);
        
        int updateset = preparedStatement2.executeUpdate();
        if (updateset > 0) {
          System.out.println("Amount updated successfully 1 debited");
        }
        PreparedStatement preparedStatement3 = conn.prepareStatement("select amount from acc where account_no = ?");
        int new_acc = Integer.parseInt(acc_no);
        preparedStatement3.setInt(1, new_acc);
        System.out.println(preparedStatement3);
        ResultSet rs1 = preparedStatement3.executeQuery();
        rs1.next();
        int new_amount1 = rs1.getInt(1) + amt;
        PreparedStatement preparedStatement4 = conn.prepareStatement("Update acc set amount = ? where account_no = ?");
        preparedStatement4.setInt(1, new_amount1);
        preparedStatement4.setInt(2, new_acc);
        int updateset2 = preparedStatement4.executeUpdate();
        if (updateset2 > 0) {
          System.out.println("Amount updated successfully 2 credited");
        }

      }
      else {
        //t_to =Integer.toString(account_no);
        //t_from =  acc_no; 
        PreparedStatement preparedStatement5 = conn.prepareStatement("select amount from acc where account_no = ?");
        preparedStatement5.setInt(1, account_no);
        System.out.println(preparedStatement5);
        ResultSet rs2 = preparedStatement5.executeQuery();
        rs2.next();
        int new_amount2 = rs2.getInt(1) + amt;
        PreparedStatement preparedStatement6 = conn.prepareStatement("Update acc set amount = ? where account_no = ?");
        preparedStatement6.setInt(1, new_amount2);
        preparedStatement6.setInt(2, account_no);
        int updateset3 = preparedStatement6.executeUpdate();
        if (updateset3 > 0) {
          System.out.println("Amount updated successfully 3");
        }
        PreparedStatement preparedStatement7 = conn.prepareStatement("select amount from acc where account_no = ?");
        int new_acc2 = Integer.parseInt(acc_no);
        preparedStatement7.setInt(1, new_acc2);
        System.out.println(preparedStatement7);
        ResultSet rs3 = preparedStatement7.executeQuery();
        rs3.next();
        int new_amount3 = rs3.getInt(1) - amt;
        PreparedStatement preparedStatement8 = conn.prepareStatement("Update acc set amount = ? where account_no = ?");
        preparedStatement8.setInt(1, new_amount3);
        preparedStatement8.setInt(2, new_acc2);
        int updateset4 = preparedStatement8.executeUpdate();
        if (updateset4 > 0) {
          System.out.println("Amount updated successfully 4");
        }
      }
      if (x == 1) {
        //PreparedStatement preparedStatement = conn.prepareStatement("select account_no from acc where name = ?");
        //		    preparedStatement.setString(1, name);
        //		    System.out.println(preparedStatement);
        //		    ResultSet rs = preparedStatement.executeQuery();
        //		    rs.next();
        //		    //System.out.print
        //			int account_no = rs.getInt(1);
        //			System.out.println(account_no);

        //session.setAttribute("account_no", account_no);
        System.out.println("Transaction happen Successfully");
        response.sendRedirect("loginsuccess.jsp");
      }
    }
    catch(Exception e) {
      System.out.print(e);
      e.printStackTrace();
    }
  }

}
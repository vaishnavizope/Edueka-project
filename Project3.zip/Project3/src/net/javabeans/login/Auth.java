package net.javabeans.login;
import java.io.Serializable;

public class Auth {
	 private static final long serialVersionUID = 1L;
	    private int Number;
	    private int CardNo;
private int CVV;
private int Amount;
public int getNumber() {
	return Number;
}
public void setNumber(int number) {
	Number = number;
}
public int getCardNo() {
	return CardNo;
}
public void setCardNo(int cardNo) {
	CardNo = cardNo;
}
public int getCVV() {
	return CVV;
}
public void setCVV(int cVV) {
	CVV = cVV;
}
public int getAmount() {
	return Amount;
}
public void setAmount(int amount) {
	Amount = amount;
}



}

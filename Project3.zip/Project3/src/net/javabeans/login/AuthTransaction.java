package net.javabeans.login;


import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.javabeans.login.Auth;
import net.javabeans.login.AuthDao;

/**
 * @email Ramesh Fadatare
 */

@WebServlet("/Authorize")
public class AuthTransaction extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private AuthDao authDao;

    public void init() {
        authDao = new AuthDao();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

       int no = Integer.parseInt(request.getParameter("n1"));

       int cardno = Integer.parseInt(request.getParameter("c1"));

       int cvv = Integer.parseInt(request.getParameter("c2"));

       int amt = Integer.parseInt(request.getParameter("a1"));
       
     
      
        Auth a = new Auth();
        a.setNumber(no);
        a.setCardNo(cardno);
        a.setCVV(cvv);
        a.setAmount(amt);
        

        try {
            if (authDao.validate(a)) {
                //HttpSession session = request.getSession();
                // session.setAttribute("username",username);
                response.sendRedirect("loginsuccess.jsp");
                System.out.println("credit Card Authorization done Successfully");
                
            } else {
                HttpSession session = request.getSession();
                System.out.println("credit Card Authorization done Fail");
                //session.setAttribute("user", username);
                //response.sendRedirect("login.jsp");
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
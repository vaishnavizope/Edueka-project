package net.javabeans.login;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
@WebServlet("/createAccount")
public class createAccount extends HttpServlet {
	private static long serialVersionUID =1L;
	PrintWriter out=new PrintWriter(System.out); 
	protected void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		String name=request.getParameter("name");
		String dob=request.getParameter("dob");
		String address=request.getParameter("Address");
		String email=request.getParameter("mail");
		String acctype=request.getParameter("account");
		int i;
		System.out.println(name+" "+dob+" "+address+" "+email+" "+acctype);
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager
		            .getConnection("jdbc:mysql://127.0.0.1:3306/login?useSSL=false", "root", "12345");
		String query="Insert into acc(Name,DOB,Address,Email,TypeAcc) values(?,?,?,?,?);";
		PreparedStatement pstmt=conn.prepareStatement(query);
		pstmt.setString(1, name);
		pstmt.setString(2, dob);
		pstmt.setString(3, address);
		pstmt.setString(4, email);
		pstmt.setString(5, acctype);
		int x=pstmt.executeUpdate();
		if(x==1) {
			PreparedStatement preparedStatement = conn.prepareStatement("select account_no from acc where name = ?");
		    preparedStatement.setString(1, name);
		    System.out.println(preparedStatement);
		    ResultSet rs = preparedStatement.executeQuery();
		    rs.next();
		    //System.out.print
			int account_no = rs.getInt(1);
			System.out.println(account_no);
			HttpSession session = request.getSession();
			session.setAttribute("account_no", account_no);
			System.out.println("Account created Successfully");
			response.sendRedirect("loginsuccess.jsp");
		}
		}
		catch(Exception e)
		{
			System.out.print(e);
			e.printStackTrace();
		}
	}

}

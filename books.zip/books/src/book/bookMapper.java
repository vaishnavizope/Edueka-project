package book;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class bookMapper implements RowMapper<bookj> { 
	public bookj mapRow(ResultSet rs, int rowNum) throws SQLException {
		bookj student = new bookj();
		student.setName(rs.getString("name"));
		student.setEmail(rs.getString("email"));
		student.setPassword(rs.getString("password"));
		return student;
	}
}

package book;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class bookMapper2 implements RowMapper<bookb> { 
	public bookb mapRow(ResultSet rs, int rowNum) throws SQLException {
		bookb book = new bookb();
		book.setTitle(rs.getString("Title"));
		book.setLanguage(rs.getString("Languages"));
		book.setPublisher(rs.getString("Publisher"));
		book.setAuthor(rs.getString("Author"));
		book.setGenre(rs.getString("Genre"));
		return book;
	}
}

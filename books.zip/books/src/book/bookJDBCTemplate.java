package book;

import java.util.List;

import javax.sql.DataSource;



import org.springframework.jdbc.core.JdbcTemplate;

public class bookJDBCTemplate implements bookDAO {
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplateObject;

	public void setDataSource(DataSource  dataSource) {
		this.dataSource = dataSource;
		this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	}

	public void create(String name,String email,String password) {
		String SQL = "insert into users (name, email, password) values (?,?, ?)";
		jdbcTemplateObject.update(SQL, name, email, password);
		System.out.println("Created Record Name=" + name);
		return;
	}
	
	public void createreview(String title,String name,String review) {
		String SQL = "insert into reviewtable (Title, Name1, Review) values (?,?, ?)";
		jdbcTemplateObject.update(SQL, title, name, review);
		System.out.println("Created Record Name=" + name);
		return;
	}

	public bookb getbook(String title) {
		String SQL = "select * from books where Title = ?";
		bookb book = jdbcTemplateObject.queryForObject(SQL,
				new Object[] { title }, new bookMapper2());
		return book;
	}
	public bookj getuser(String email) {
		String SQL = "select * from users where email = ?";
		bookj book = jdbcTemplateObject.queryForObject(SQL,
				new Object[] { email }, new bookMapper());
		return book;
	}

	public List<bookb> listbooks() {
		String SQL = "select * from books";
		List<bookb> books = jdbcTemplateObject.query(SQL,
				new bookMapper2());
		return books;
	}
	
	public List<bookb> listbooks(String str) {
		String SQL = "select * from books where Title like ? or Languages like ? or Publisher like ? or Author like ? or Genre like ? ";
		str="%"+str+"%";
		List<bookb> books = jdbcTemplateObject.query(SQL,
				new Object[] {str,str,str,str,str},new bookMapper2());
		return books;
	}
	
	public List<bookr> listreviews(String title) {
		String SQL = "select * from reviewtable where Title= ?";
		List<bookr> books = jdbcTemplateObject.query(SQL,
				new Object[] {title},new bookMapper3());
		return books;
	}	
	
}

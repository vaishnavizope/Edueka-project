package book;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class bookMapper3 implements RowMapper<bookr> { 
	public bookr mapRow(ResultSet rs, int rowNum) throws SQLException {
		bookr book = new bookr();
		book.setTitle(rs.getString("Title"));
		book.setName(rs.getString("Name1"));
		book.setReview(rs.getString("Review"));
		return book;
	}
}

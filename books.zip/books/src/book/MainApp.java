package book;
import java.util.*;
import java.io.*;

import book.bookDAO;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.ui.ModelMap;

@Controller
public class MainApp {
	List<String> title= new ArrayList<String>(20);
	List<String> language= new ArrayList<String>(20);
	List<String> publisher= new ArrayList<String>(20);
	List<String> author= new ArrayList<String>(20);
	List<String> genre= new ArrayList<String>(20);
	@RequestMapping("/signup")
	   public ModelAndView lonin2(HttpServletRequest req,HttpServletResponse res) {
		   ModelAndView model=new ModelAndView();
		      model.setViewName("signup");
		      return model;		
		   }
   @RequestMapping("/signup1")
   public ModelAndView signup1(HttpServletRequest req,HttpServletResponse res) {
	   ModelAndView model=new ModelAndView();
	   String str1= req.getParameter("t1");
	   String str2= req.getParameter("t2");
	   String str3= req.getParameter("t3");
	   HttpSession session=req.getSession(); 
	   session.setAttribute("name",str1);
	      model.addObject("message1", str1);
	      model.addObject("message2", str2);
	      model.addObject("message2", str3);
	      model.setViewName("display");
	      ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml"); 
		  bookJDBCTemplate bookJDBCTemplateobj = (bookJDBCTemplate) context.getBean("bookJDBCTemplate");
		  bookJDBCTemplateobj.create(str1, str2, str3);
		  List<bookb> book = bookJDBCTemplateobj.listbooks();
		  model.addObject("books",book );
		  model.setViewName("display");
	      return model;	
	   }
   @RequestMapping("/login")
   public ModelAndView login(HttpServletRequest req,HttpServletResponse res) {
	   ModelAndView model=new ModelAndView();
	      model.setViewName("login");
	      return model;		
	   }
   @RequestMapping("/login1")
   public ModelAndView lonin1(HttpServletRequest req,HttpServletResponse res) {
	   ModelAndView model=new ModelAndView();
	   String str1= req.getParameter("l1");
	   String str2= req.getParameter("l2");
	      model.addObject("message1", str1);
	      model.addObject("message2", str2);
	      ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml"); 
		  bookJDBCTemplate bookJDBCTemplateobj = (bookJDBCTemplate) context.getBean("bookJDBCTemplate");
		  bookj b= bookJDBCTemplateobj.getuser(str1);
		  String name=b.getName();
		  String email= b.getEmail();
		  String password=b.getPassword();
		  
		  if(email.equals(str1)&&password.equals(str2))
		  {
			  model.setViewName("display");
			  HttpSession session=req.getSession(); 
			  session.setAttribute("name",name);
			  List<bookb> book = bookJDBCTemplateobj.listbooks();
			  model.addObject("books",book );
			  model.setViewName("display");	  
		  }
		  else
		  {
			  model.setViewName("error");
		  }
	      return model;	
	   }
   @RequestMapping("/display")
   public ModelAndView display(HttpServletRequest req,HttpServletResponse res) {
	   ModelAndView model=new ModelAndView();
	   System.out.println("------Listing Multiple Records--------");
	   ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml"); 
	   bookJDBCTemplate bookJDBCTemplateobj = (bookJDBCTemplate) context.getBean("bookJDBCTemplate");
		List<bookb> book = bookJDBCTemplateobj.listbooks();
		  model.addObject("books",book );
		  model.setViewName("display");
	      return model;		
	   }
   @RequestMapping("/review")
   public ModelAndView review(HttpServletRequest req,HttpServletResponse res) {
	   ModelAndView model=new ModelAndView();
	   String str= req.getParameter("button1");
	   HttpSession session=req.getSession(false);
	   String str2=(String)session.getAttribute("name");
	   model.addObject("bookname",str);
	   model.addObject("username",str2);
	   ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml"); 
	   bookJDBCTemplate bookJDBCTemplateobj = (bookJDBCTemplate) context.getBean("bookJDBCTemplate");
	   List<bookr> book = bookJDBCTemplateobj.listreviews(str);
	   bookb bookb = bookJDBCTemplateobj.getbook(str);
	   model.addObject("bookb",bookb);
	   model.addObject("reviews",book);
	   model.setViewName("review");
	   return model;		
	   }
   @RequestMapping("/addreview")
   public ModelAndView addreview(HttpServletRequest req,HttpServletResponse res) {
	   ModelAndView model=new ModelAndView();
	   String str= req.getParameter("button2");
	   String str3= req.getParameter("rev");
	   HttpSession session=req.getSession(false);
	   String str2=(String)session.getAttribute("name");
	   model.addObject("bookname",str);
	   model.addObject("username",str2);
	   ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml"); 
	   bookJDBCTemplate bookJDBCTemplateobj = (bookJDBCTemplate) context.getBean("bookJDBCTemplate");
	   bookJDBCTemplateobj.createreview(str,str2,str3);
	   List<bookr> book = bookJDBCTemplateobj.listreviews(str);
	   bookb bookb = bookJDBCTemplateobj.getbook(str);
	   model.addObject("bookb",bookb);
	   model.addObject("reviews",book);
	   model.setViewName("review");
	   return model;		
	   }
   @RequestMapping("/search")
   public ModelAndView search(HttpServletRequest req,HttpServletResponse res) {
	   ModelAndView model=new ModelAndView();
	   System.out.println("hello");
	   String str= req.getParameter("search");
	   HttpSession session=req.getSession(false);
	   String str2=(String)session.getAttribute("name");
	   model.addObject("str",str);
	   model.addObject("username",str2);
	   ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml"); 
	   bookJDBCTemplate bookJDBCTemplateobj = (bookJDBCTemplate) context.getBean("bookJDBCTemplate");
	   System.out.println(str);
	   List<bookb> book = bookJDBCTemplateobj.listbooks(str);
	   model.addObject("books",book );
	   model.setViewName("display");
	   return model;		
	   }
   
}	
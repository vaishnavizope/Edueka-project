package book;

import java.util.List;

import javax.sql.DataSource;

public interface bookDAO {

	
	public void setDataSource(DataSource ds);


	public void create(String name,String email,String password);
	
	public bookb getbook(String title);
	
	public bookj getuser(String email);

	public List<bookb> listbooks();
}
